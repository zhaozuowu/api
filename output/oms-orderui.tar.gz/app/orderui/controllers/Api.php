<?php
/**
 * @name Controller_Api
 * @desc 订单模块Api Controller_Api
 * @author yu.jin03@ele.me 
 */
class Controller_Api extends Ap_Controller_Abstract {
    public $actions = array(
    );
}
