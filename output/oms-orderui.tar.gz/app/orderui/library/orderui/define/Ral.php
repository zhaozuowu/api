<?php
/**
 * @name Order_Define_Ral
 * @desc Order_Define_Ral
 * @author lvbochao@iwaimai.baidu.com
 */
class Order_Define_Ral
{
    const NWMS_ORDER_CREATE_RESERVE_ORDER_WRITE = 'createreserveorderwrite';
}