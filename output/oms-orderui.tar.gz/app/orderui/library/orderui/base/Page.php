<?php
/**
 * @name Order_Base_Page
 * @desc Order_Base_Page
 * @author lvbochao@iwaimai.baidu.com
 */
interface Order_Base_Page {

    /**
     * function execute
     * @param array $arrInput
     * @return array
     */
    public function execute($arrInput);
}