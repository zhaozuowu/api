<?php
/**
 * @name Order_Wmq_CommitAction
 * @desc order wmq commit action
 * @author jinyu02@iwaimai.baidu.com
 */
class Order_Wmq_CommitAction extends Wm_Lib_Wmq_CommitAction {

}
